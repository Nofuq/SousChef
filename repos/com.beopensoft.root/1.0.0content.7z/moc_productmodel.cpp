/****************************************************************************
** Meta object code from reading C++ file 'productmodel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/productmodel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'productmodel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ProductModel_t {
    QByteArrayData data[39];
    char stringdata0[479];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ProductModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ProductModel_t qt_meta_stringdata_ProductModel = {
    {
QT_MOC_LITERAL(0, 0, 12), // "ProductModel"
QT_MOC_LITERAL(1, 13, 12), // "productReady"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 7), // "orderId"
QT_MOC_LITERAL(4, 35, 10), // "productsId"
QT_MOC_LITERAL(5, 46, 15), // "searchByOrderId"
QT_MOC_LITERAL(6, 62, 6), // "search"
QT_MOC_LITERAL(7, 69, 25), // "Product::CookingStateEnum"
QT_MOC_LITERAL(8, 95, 5), // "state"
QT_MOC_LITERAL(9, 101, 13), // "searchByGroup"
QT_MOC_LITERAL(10, 115, 7), // "groupId"
QT_MOC_LITERAL(11, 123, 10), // "searchById"
QT_MOC_LITERAL(12, 134, 9), // "productId"
QT_MOC_LITERAL(13, 144, 3), // "get"
QT_MOC_LITERAL(14, 148, 3), // "row"
QT_MOC_LITERAL(15, 152, 15), // "setCookingDelay"
QT_MOC_LITERAL(16, 168, 4), // "guid"
QT_MOC_LITERAL(17, 173, 7), // "minutes"
QT_MOC_LITERAL(18, 181, 10), // "setCooking"
QT_MOC_LITERAL(19, 192, 13), // "pushToCooking"
QT_MOC_LITERAL(20, 206, 8), // "setReady"
QT_MOC_LITERAL(21, 215, 11), // "pushToReady"
QT_MOC_LITERAL(22, 227, 18), // "pushProductToReady"
QT_MOC_LITERAL(23, 246, 20), // "pushProductToCooking"
QT_MOC_LITERAL(24, 267, 12), // "serveProduct"
QT_MOC_LITERAL(25, 280, 5), // "Roles"
QT_MOC_LITERAL(26, 286, 6), // "IDRole"
QT_MOC_LITERAL(27, 293, 11), // "OrderIdRole"
QT_MOC_LITERAL(28, 305, 8), // "NameRole"
QT_MOC_LITERAL(29, 314, 10), // "AmountRole"
QT_MOC_LITERAL(30, 325, 11), // "GroupIdRole"
QT_MOC_LITERAL(31, 337, 10), // "CourseRole"
QT_MOC_LITERAL(32, 348, 11), // "CommentRole"
QT_MOC_LITERAL(33, 360, 16), // "CookingStateRole"
QT_MOC_LITERAL(34, 377, 18), // "EstCookingSecsRole"
QT_MOC_LITERAL(35, 396, 23), // "EstCookingStartTimeRole"
QT_MOC_LITERAL(36, 420, 24), // "EstCookingFinishTimeRole"
QT_MOC_LITERAL(37, 445, 17), // "PushToCookingRole"
QT_MOC_LITERAL(38, 463, 15) // "PushToReadyRole"

    },
    "ProductModel\0productReady\0\0orderId\0"
    "productsId\0searchByOrderId\0search\0"
    "Product::CookingStateEnum\0state\0"
    "searchByGroup\0groupId\0searchById\0"
    "productId\0get\0row\0setCookingDelay\0"
    "guid\0minutes\0setCooking\0pushToCooking\0"
    "setReady\0pushToReady\0pushProductToReady\0"
    "pushProductToCooking\0serveProduct\0"
    "Roles\0IDRole\0OrderIdRole\0NameRole\0"
    "AmountRole\0GroupIdRole\0CourseRole\0"
    "CommentRole\0CookingStateRole\0"
    "EstCookingSecsRole\0EstCookingStartTimeRole\0"
    "EstCookingFinishTimeRole\0PushToCookingRole\0"
    "PushToReadyRole"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ProductModel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       1,  144, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   89,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
       5,    1,   94,    2, 0x02 /* Public */,
       6,    2,   97,    2, 0x02 /* Public */,
       6,    1,  102,    2, 0x22 /* Public | MethodCloned */,
       9,    2,  105,    2, 0x02 /* Public */,
      11,    2,  110,    2, 0x02 /* Public */,
      13,    1,  115,    2, 0x02 /* Public */,
      15,    2,  118,    2, 0x02 /* Public */,
      18,    2,  123,    2, 0x02 /* Public */,
      19,    0,  128,    2, 0x02 /* Public */,
      20,    2,  129,    2, 0x02 /* Public */,
      21,    0,  134,    2, 0x02 /* Public */,
      22,    1,  135,    2, 0x02 /* Public */,
      23,    1,  138,    2, 0x02 /* Public */,
      24,    1,  141,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QStringList,    3,    4,

 // methods: parameters
    QMetaType::QStringList, QMetaType::QString,    3,
    QMetaType::QVariantList, QMetaType::QString, 0x80000000 | 7,    3,    8,
    QMetaType::QVariantList, QMetaType::QString,    3,
    QMetaType::QVariantList, QMetaType::Int, 0x80000000 | 7,   10,    8,
    QMetaType::QVariantList, QMetaType::QString, 0x80000000 | 7,   12,    8,
    QMetaType::QVariant, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   16,   17,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   16,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   16,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void, QMetaType::QString,   16,

 // enums: name, flags, count, data
      25, 0x0,   13,  148,

 // enum data: key, value
      26, uint(ProductModel::IDRole),
      27, uint(ProductModel::OrderIdRole),
      28, uint(ProductModel::NameRole),
      29, uint(ProductModel::AmountRole),
      30, uint(ProductModel::GroupIdRole),
      31, uint(ProductModel::CourseRole),
      32, uint(ProductModel::CommentRole),
      33, uint(ProductModel::CookingStateRole),
      34, uint(ProductModel::EstCookingSecsRole),
      35, uint(ProductModel::EstCookingStartTimeRole),
      36, uint(ProductModel::EstCookingFinishTimeRole),
      37, uint(ProductModel::PushToCookingRole),
      38, uint(ProductModel::PushToReadyRole),

       0        // eod
};

void ProductModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ProductModel *_t = static_cast<ProductModel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->productReady((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QStringList(*)>(_a[2]))); break;
        case 1: { QStringList _r = _t->searchByOrderId((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 2: { QVariantList _r = _t->search((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< Product::CookingStateEnum(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QVariantList*>(_a[0]) = std::move(_r); }  break;
        case 3: { QVariantList _r = _t->search((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariantList*>(_a[0]) = std::move(_r); }  break;
        case 4: { QVariantList _r = _t->searchByGroup((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< Product::CookingStateEnum(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QVariantList*>(_a[0]) = std::move(_r); }  break;
        case 5: { QVariantList _r = _t->searchById((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< Product::CookingStateEnum(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QVariantList*>(_a[0]) = std::move(_r); }  break;
        case 6: { QVariant _r = _t->get((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = std::move(_r); }  break;
        case 7: _t->setCookingDelay((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 8: _t->setCooking((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 9: _t->pushToCooking(); break;
        case 10: _t->setReady((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 11: _t->pushToReady(); break;
        case 12: _t->pushProductToReady((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->pushProductToCooking((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->serveProduct((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (ProductModel::*_t)(QString , QStringList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ProductModel::productReady)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject ProductModel::staticMetaObject = {
    { &QAbstractListModel::staticMetaObject, qt_meta_stringdata_ProductModel.data,
      qt_meta_data_ProductModel,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ProductModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ProductModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ProductModel.stringdata0))
        return static_cast<void*>(this);
    return QAbstractListModel::qt_metacast(_clname);
}

int ProductModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractListModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void ProductModel::productReady(QString _t1, QStringList _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
