/****************************************************************************
** Meta object code from reading C++ file 'product.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/product.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'product.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Product_t {
    QByteArrayData data[52];
    char stringdata0[690];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Product_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Product_t qt_meta_stringdata_Product = {
    {
QT_MOC_LITERAL(0, 0, 7), // "Product"
QT_MOC_LITERAL(1, 8, 9), // "idChanged"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 2), // "id"
QT_MOC_LITERAL(4, 22, 14), // "orderIdChanged"
QT_MOC_LITERAL(5, 37, 7), // "orderId"
QT_MOC_LITERAL(6, 45, 11), // "nameChanged"
QT_MOC_LITERAL(7, 57, 4), // "name"
QT_MOC_LITERAL(8, 62, 13), // "amountChanged"
QT_MOC_LITERAL(9, 76, 6), // "amount"
QT_MOC_LITERAL(10, 83, 14), // "groupIdChanged"
QT_MOC_LITERAL(11, 98, 7), // "groupId"
QT_MOC_LITERAL(12, 106, 13), // "courseChanged"
QT_MOC_LITERAL(13, 120, 6), // "course"
QT_MOC_LITERAL(14, 127, 15), // "commentsChanged"
QT_MOC_LITERAL(15, 143, 7), // "comment"
QT_MOC_LITERAL(16, 151, 19), // "cookingStateChanged"
QT_MOC_LITERAL(17, 171, 16), // "CookingStateEnum"
QT_MOC_LITERAL(18, 188, 12), // "cookingState"
QT_MOC_LITERAL(19, 201, 21), // "estCookingSecsChanged"
QT_MOC_LITERAL(20, 223, 14), // "estCookingSecs"
QT_MOC_LITERAL(21, 238, 26), // "estCookingStartTimeChanged"
QT_MOC_LITERAL(22, 265, 19), // "estCookingStartTime"
QT_MOC_LITERAL(23, 285, 27), // "estCookingFinishTimeChanged"
QT_MOC_LITERAL(24, 313, 20), // "estCookingFinishTime"
QT_MOC_LITERAL(25, 334, 20), // "pushToCookingChanged"
QT_MOC_LITERAL(26, 355, 13), // "pushToCooking"
QT_MOC_LITERAL(27, 369, 18), // "pushToReadyChanged"
QT_MOC_LITERAL(28, 388, 11), // "pushToReady"
QT_MOC_LITERAL(29, 400, 12), // "productAdded"
QT_MOC_LITERAL(30, 413, 5), // "setId"
QT_MOC_LITERAL(31, 419, 10), // "setOrderId"
QT_MOC_LITERAL(32, 430, 7), // "setName"
QT_MOC_LITERAL(33, 438, 9), // "setAmount"
QT_MOC_LITERAL(34, 448, 10), // "setGroupId"
QT_MOC_LITERAL(35, 459, 9), // "setCourse"
QT_MOC_LITERAL(36, 469, 11), // "setComments"
QT_MOC_LITERAL(37, 481, 8), // "comments"
QT_MOC_LITERAL(38, 490, 15), // "setCookingState"
QT_MOC_LITERAL(39, 506, 17), // "setEstCookingSecs"
QT_MOC_LITERAL(40, 524, 22), // "setEstCookingStartTime"
QT_MOC_LITERAL(41, 547, 23), // "setEstCookingFinishTime"
QT_MOC_LITERAL(42, 571, 16), // "setPushToCooking"
QT_MOC_LITERAL(43, 588, 14), // "setPushToReady"
QT_MOC_LITERAL(44, 603, 4), // "fill"
QT_MOC_LITERAL(45, 608, 8), // "Product*"
QT_MOC_LITERAL(46, 617, 12), // "PendingState"
QT_MOC_LITERAL(47, 630, 12), // "CookingState"
QT_MOC_LITERAL(48, 643, 10), // "ReadyState"
QT_MOC_LITERAL(49, 654, 12), // "CarriedState"
QT_MOC_LITERAL(50, 667, 13), // "ArchivedState"
QT_MOC_LITERAL(51, 681, 8) // "AnyState"

    },
    "Product\0idChanged\0\0id\0orderIdChanged\0"
    "orderId\0nameChanged\0name\0amountChanged\0"
    "amount\0groupIdChanged\0groupId\0"
    "courseChanged\0course\0commentsChanged\0"
    "comment\0cookingStateChanged\0"
    "CookingStateEnum\0cookingState\0"
    "estCookingSecsChanged\0estCookingSecs\0"
    "estCookingStartTimeChanged\0"
    "estCookingStartTime\0estCookingFinishTimeChanged\0"
    "estCookingFinishTime\0pushToCookingChanged\0"
    "pushToCooking\0pushToReadyChanged\0"
    "pushToReady\0productAdded\0setId\0"
    "setOrderId\0setName\0setAmount\0setGroupId\0"
    "setCourse\0setComments\0comments\0"
    "setCookingState\0setEstCookingSecs\0"
    "setEstCookingStartTime\0setEstCookingFinishTime\0"
    "setPushToCooking\0setPushToReady\0fill\0"
    "Product*\0PendingState\0CookingState\0"
    "ReadyState\0CarriedState\0ArchivedState\0"
    "AnyState"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Product[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
      13,  256, // properties
       1,  308, // enums/sets
       0,    0, // constructors
       0,       // flags
      14,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  154,    2, 0x06 /* Public */,
       4,    1,  157,    2, 0x06 /* Public */,
       6,    1,  160,    2, 0x06 /* Public */,
       8,    1,  163,    2, 0x06 /* Public */,
      10,    1,  166,    2, 0x06 /* Public */,
      12,    1,  169,    2, 0x06 /* Public */,
      14,    1,  172,    2, 0x06 /* Public */,
      16,    1,  175,    2, 0x06 /* Public */,
      19,    1,  178,    2, 0x06 /* Public */,
      21,    1,  181,    2, 0x06 /* Public */,
      23,    1,  184,    2, 0x06 /* Public */,
      25,    1,  187,    2, 0x06 /* Public */,
      27,    1,  190,    2, 0x06 /* Public */,
      29,    0,  193,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      30,    1,  194,    2, 0x0a /* Public */,
      31,    1,  197,    2, 0x0a /* Public */,
      32,    1,  200,    2, 0x0a /* Public */,
      33,    1,  203,    2, 0x0a /* Public */,
      34,    1,  206,    2, 0x0a /* Public */,
      35,    1,  209,    2, 0x0a /* Public */,
      36,    1,  212,    2, 0x0a /* Public */,
      38,    1,  215,    2, 0x0a /* Public */,
      39,    1,  218,    2, 0x0a /* Public */,
      40,    1,  221,    2, 0x0a /* Public */,
      41,    1,  224,    2, 0x0a /* Public */,
      42,    1,  227,    2, 0x0a /* Public */,
      43,    1,  230,    2, 0x0a /* Public */,
      44,   11,  233,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::QDateTime,   22,
    QMetaType::Void, QMetaType::QDateTime,   24,
    QMetaType::Void, QMetaType::Bool,   26,
    QMetaType::Void, QMetaType::Bool,   28,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::QDateTime,   22,
    QMetaType::Void, QMetaType::QDateTime,   24,
    QMetaType::Void, QMetaType::Bool,   26,
    QMetaType::Void, QMetaType::Bool,   28,
    0x80000000 | 45, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::QString, 0x80000000 | 17, QMetaType::Int, QMetaType::QDateTime, QMetaType::QDateTime,    3,    5,    7,    9,   11,   13,   37,   18,   20,   22,   24,

 // properties: name, type, flags
       3, QMetaType::QString, 0x00495103,
       5, QMetaType::QString, 0x00495103,
       7, QMetaType::QString, 0x00495103,
       9, QMetaType::Int, 0x00495103,
      11, QMetaType::Int, 0x00495103,
      13, QMetaType::Int, 0x00495103,
      37, QMetaType::QString, 0x00495103,
      18, 0x80000000 | 17, 0x0049510b,
      20, QMetaType::Int, 0x00495103,
      22, QMetaType::QDateTime, 0x00495103,
      24, QMetaType::QDateTime, 0x00495103,
      26, QMetaType::Bool, 0x00495103,
      28, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,
       8,
       9,
      10,
      11,
      12,

 // enums: name, flags, count, data
      17, 0x2,    6,  312,

 // enum data: key, value
      46, uint(Product::CookingStateEnum::PendingState),
      47, uint(Product::CookingStateEnum::CookingState),
      48, uint(Product::CookingStateEnum::ReadyState),
      49, uint(Product::CookingStateEnum::CarriedState),
      50, uint(Product::CookingStateEnum::ArchivedState),
      51, uint(Product::CookingStateEnum::AnyState),

       0        // eod
};

void Product::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Product *_t = static_cast<Product *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->idChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->orderIdChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->nameChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->amountChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->groupIdChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->courseChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->commentsChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->cookingStateChanged((*reinterpret_cast< CookingStateEnum(*)>(_a[1]))); break;
        case 8: _t->estCookingSecsChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->estCookingStartTimeChanged((*reinterpret_cast< QDateTime(*)>(_a[1]))); break;
        case 10: _t->estCookingFinishTimeChanged((*reinterpret_cast< QDateTime(*)>(_a[1]))); break;
        case 11: _t->pushToCookingChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->pushToReadyChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->productAdded(); break;
        case 14: _t->setId((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->setOrderId((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 16: _t->setName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->setAmount((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->setGroupId((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->setCourse((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->setComments((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 21: _t->setCookingState((*reinterpret_cast< CookingStateEnum(*)>(_a[1]))); break;
        case 22: _t->setEstCookingSecs((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->setEstCookingStartTime((*reinterpret_cast< QDateTime(*)>(_a[1]))); break;
        case 24: _t->setEstCookingFinishTime((*reinterpret_cast< QDateTime(*)>(_a[1]))); break;
        case 25: _t->setPushToCooking((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->setPushToReady((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: { Product* _r = _t->fill((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< CookingStateEnum(*)>(_a[8])),(*reinterpret_cast< int(*)>(_a[9])),(*reinterpret_cast< QDateTime(*)>(_a[10])),(*reinterpret_cast< QDateTime(*)>(_a[11])));
            if (_a[0]) *reinterpret_cast< Product**>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (Product::*_t)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::idChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Product::*_t)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::orderIdChanged)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Product::*_t)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::nameChanged)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Product::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::amountChanged)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (Product::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::groupIdChanged)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (Product::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::courseChanged)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (Product::*_t)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::commentsChanged)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (Product::*_t)(CookingStateEnum );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::cookingStateChanged)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (Product::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::estCookingSecsChanged)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (Product::*_t)(QDateTime );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::estCookingStartTimeChanged)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (Product::*_t)(QDateTime );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::estCookingFinishTimeChanged)) {
                *result = 10;
                return;
            }
        }
        {
            typedef void (Product::*_t)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::pushToCookingChanged)) {
                *result = 11;
                return;
            }
        }
        {
            typedef void (Product::*_t)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::pushToReadyChanged)) {
                *result = 12;
                return;
            }
        }
        {
            typedef void (Product::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Product::productAdded)) {
                *result = 13;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        Product *_t = static_cast<Product *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->id(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->orderId(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->name(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->amount(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->groupId(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->course(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->comments(); break;
        case 7: *reinterpret_cast< CookingStateEnum*>(_v) = _t->cookingState(); break;
        case 8: *reinterpret_cast< int*>(_v) = _t->estCookingSecs(); break;
        case 9: *reinterpret_cast< QDateTime*>(_v) = _t->estCookingStartTime(); break;
        case 10: *reinterpret_cast< QDateTime*>(_v) = _t->estCookingFinishTime(); break;
        case 11: *reinterpret_cast< bool*>(_v) = _t->pushToCooking(); break;
        case 12: *reinterpret_cast< bool*>(_v) = _t->pushToReady(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        Product *_t = static_cast<Product *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setId(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setOrderId(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setName(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setAmount(*reinterpret_cast< int*>(_v)); break;
        case 4: _t->setGroupId(*reinterpret_cast< int*>(_v)); break;
        case 5: _t->setCourse(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setComments(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setCookingState(*reinterpret_cast< CookingStateEnum*>(_v)); break;
        case 8: _t->setEstCookingSecs(*reinterpret_cast< int*>(_v)); break;
        case 9: _t->setEstCookingStartTime(*reinterpret_cast< QDateTime*>(_v)); break;
        case 10: _t->setEstCookingFinishTime(*reinterpret_cast< QDateTime*>(_v)); break;
        case 11: _t->setPushToCooking(*reinterpret_cast< bool*>(_v)); break;
        case 12: _t->setPushToReady(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject Product::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Product.data,
      qt_meta_data_Product,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Product::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Product::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Product.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Product::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Product::idChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Product::orderIdChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Product::nameChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Product::amountChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Product::groupIdChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Product::courseChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Product::commentsChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void Product::cookingStateChanged(CookingStateEnum _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void Product::estCookingSecsChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void Product::estCookingStartTimeChanged(QDateTime _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void Product::estCookingFinishTimeChanged(QDateTime _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void Product::pushToCookingChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void Product::pushToReadyChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void Product::productAdded()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
